plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.professionalreloaded"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.professionalreloaded"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
