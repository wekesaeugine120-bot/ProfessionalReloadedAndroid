# Professional Reloaded — Android wrapper project

This Android Studio project opens the existing Professional Reloaded website:
https://convivial-pro-proof-hub.base44.app/

## Build it
1. Install Android Studio (current stable release) and the Android SDK.
2. Open this folder in Android Studio.
3. Allow Gradle sync to complete.
4. Test on an Android emulator and on a physical Android phone.
5. For a test APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. For Google Play: Build > Generate Signed Bundle / APK > Android App Bundle.
   Create and securely back up your own upload/signing key.

## Important before publishing
- This is a WebView wrapper, not a native rewrite of the website.
- The website must work well on mobile and permit embedding in Android WebView.
- Test sign-in, registration, uploads, downloads, payment flows (if any), external links,
  cookies, privacy/consent flows and all important user journeys on real devices.
- Add a production launcher icon and complete store listing assets.
- Publish under your own Google Play developer account and comply with current Play policies.
- The application ID `app.professionalreloaded` is a starter identifier. Confirm it is
  available and choose your final permanent ID before the first Play release.
- Review privacy disclosures and Data safety answers against the actual website/app data
  practices. Do not submit until these are verified.

## Current configuration
- App name: Professional Reloaded
- Version: 1.0.0 (versionCode 1)
- Minimum Android: 6.0 (API 23)
- Target SDK: 35


## Build from a phone (no Android Studio app needed)
This project includes a GitHub Actions workflow for a cloud APK build.

1. In your phone browser, sign in to https://github.com/ (create an account if needed).
2. Create a new repository, for example `professional-reloaded-android`.
3. Upload the contents of this ZIP into the repository (including the hidden `.github` folder).
4. Open the repository's **Actions** tab.
5. Select **Build Professional Reloaded APK**, then tap **Run workflow**.
6. When the run completes successfully, open it, find **Artifacts**, and download
   `ProfessionalReloaded-debug-apk`.
7. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone.
   Android may ask you to allow installation from your browser or file manager.

This creates a debug APK for testing only. A Play Store release requires a properly
signed release App Bundle (AAB), final privacy/data-safety review, and Play Console setup.
